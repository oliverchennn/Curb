# Curb R2 core verification

Tested source: 64f004c5e0ea7062d29165d8dfc5acfde7fa04b2
Commands use the existing repository lockfile with Node 24.12.0 and npm 11.6.2.
No product source, test, package or configuration changes were made.

Run from the exact source checkout:

    npm ci
    npm run check
    npm run start -- --port 3000

Use the second terminal after the loopback health route returns 200. Replace the verifier path and loopback port if needed.

    node verify-core-http.mjs http://127.0.0.1:3000 64f004c5e0ea7062d29165d8dfc5acfde7fa04b2

The verifier imports only Node built-ins. It inputs evidence from live loopback GET responses, independently enumerates recursive subsets and authored simple directed paths, and compares the complete response for each plan budget and R1 trip request. It writes core-http-evidence.json beside the script. Stop the process after the run. The historical R1 evidence directory is untouched.

This evidence covers the API/domain core, including Foundation and R1 API regressions. It does not cover the pending R2 browser UI, field conditions, deployment, or performance beyond the authored graph.
