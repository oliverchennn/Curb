import assert from 'node:assert/strict';
import { writeFile } from 'node:fs/promises';
import { performance } from 'node:perf_hooks';
import { join } from 'node:path';

const base = new URL(process.argv[2] ?? 'http://127.0.0.1:3000');
assert.equal(base.protocol, 'http:');
assert.equal(base.hostname, '127.0.0.1', 'Run this verifier against a local production preview.');
const sourceSha = process.argv[3];
assert.match(sourceSha ?? '', /^[0-9a-f]{40}$/);
const startedAt = new Date().toISOString();
const timings = { core: [], r1: [], foundation: [] };

async function request({ path, expectedStatus = 200, code, version, input, raw, group }) {
  const body = raw ?? (input === undefined ? undefined : JSON.stringify(input));
  const started = performance.now();
  const reply = await fetch(new URL(path, base), {
    method: body === undefined ? 'GET' : 'POST',
    headers: body === undefined ? undefined : { 'Content-Type': 'application/json' },
    body,
    signal: AbortSignal.timeout(15000),
    redirect: 'error',
  });
  const text = await reply.text();
  const elapsedMs = performance.now() - started;
  timings[group].push(elapsedMs);
  assert.equal(reply.status, expectedStatus, path + ' returned ' + text);
  assert.equal(reply.headers.get('cache-control'), 'no-store', path);
  assert.match(reply.headers.get('content-type') ?? '', /^application\/json\b/, path);
  const value = JSON.parse(text);
  if (version) assert.equal(value.contractVersion, version, path);
  const keys = version ? ['contractVersion', 'ok'] : ['ok'];
  if (code) {
    assert.deepEqual(Object.keys(value).sort(), [...keys, 'error'].sort());
    assert.equal(value.ok, false);
    assert.deepEqual(Object.keys(value.error).sort(), ['code', 'message']);
    assert.equal(value.error.code, code);
    assert.equal(typeof value.error.message, 'string');
    assert(value.error.message.trim());
  } else {
    assert.deepEqual(Object.keys(value).sort(), [...keys, 'data'].sort());
    assert.equal(value.ok, true);
  }
  return { value, text, elapsedMs };
}

function compareIds(left, right) {
  return left === right ? 0 : left < right ? -1 : 1;
}

function compareLists(left, right) {
  for (let index = 0; index < Math.min(left.length, right.length); index++) {
    const order = compareIds(left[index], right[index]);
    if (order) return order;
  }
  return left.length - right.length;
}

function comparePaths(left, right) {
  return left.distanceMeters - right.distanceMeters ||
    compareLists(left.edgeIds, right.edgeIds) ||
    compareLists(left.nodeIds, right.nodeIds);
}

// Independent exhaustive DFS of simple directed paths. The HTTP context supplies
// graph data only. No app, test fixture, product schema, or evaluator is imported.
function graphOracle(context) {
  const { scenario, edgeAssessments, repairs } = context;
  const outgoing = new Map(scenario.nodes.map(({ id }) => [id, []]));
  const assessments = new Map(edgeAssessments.map((entry) => [entry.edgeId, entry]));
  const barrierByRepair = new Map(repairs.map(({ id, barrierId }) => [id, barrierId]));
  const targetByDestination = new Map(scenario.destinations.map(({ id, nodeId }) => [id, nodeId]));
  for (const edge of scenario.edges) {
    outgoing.get(edge.fromNodeId).push({ to: edge.toNodeId, edge });
    if (edge.bidirectional) outgoing.get(edge.toNodeId).push({ to: edge.fromNodeId, edge });
  }
  const pathCache = new Map();
  function paths(origin, target) {
    const key = JSON.stringify([origin, target]);
    if (pathCache.has(key)) return pathCache.get(key);

    function* walk(nodeIds, edgeIds, distanceMeters) {
      const node = nodeIds.at(-1);
      if (node === target) {
        yield { nodeIds, edgeIds, distanceMeters };
        return;
      }
      for (const { to, edge } of outgoing.get(node)) {
        if (nodeIds.includes(to)) continue;
        yield* walk([...nodeIds, to], [...edgeIds, edge.id], distanceMeters + edge.lengthMeters);
      }
    }
    const result = [...walk([origin], [], 0)].sort(comparePaths);
    pathCache.set(key, result);
    return result;
  }

  function route(origin, destinationId, repairIds) {
    const cleared = new Set(repairIds.map((id) => {
      assert(barrierByRepair.has(id), 'Expected an authored repair: ' + id);
      return barrierByRepair.get(id);
    }));
    const state = (id) => {
      const assessment = assessments.get(id);
      if (assessment.blockingBarrierIds.some((barrierId) => !cleared.has(barrierId))) return 'blocked';
      return assessment.status === 'unknown' ? 'unknown' : 'pass';
    };
    const candidates = paths(origin, targetByDestination.get(destinationId));
    const passing = candidates.find(({ edgeIds }) => edgeIds.every((id) => state(id) === 'pass'));
    if (passing) return { status: 'reachable', ...passing };

    const unknown = candidates.find(({ edgeIds }) => edgeIds.every((id) => state(id) !== 'blocked'));
    if (unknown) {
      return { status: 'unknown', blockedEdgeIds: [], unknownEdgeIds: unknown.edgeIds.filter((id) => state(id) === 'unknown') };
    }
    const structural = candidates[0];
    if (!structural) return { status: 'disconnected', blockedEdgeIds: [], unknownEdgeIds: [] };
    return {
      status: 'blocked',
      blockedEdgeIds: structural.edgeIds.filter((id) => state(id) === 'blocked'),
      unknownEdgeIds: structural.edgeIds.filter((id) => state(id) === 'unknown'),
    };
  }

  return { route, originIds: [...outgoing.keys()], destinationIds: [...targetByDestination.keys()] };
}

function* subsets(ids, index = 0, selected = []) {
  if (index === ids.length) {
    yield selected;
    return;
  }
  yield* subsets(ids, index + 1, selected);
  yield* subsets(ids, index + 1, [...selected, ids[index]]);
}

function requestIdentity(context, version) {
  return {
    contractVersion: version,
    scenarioId: context.scenario.id,
    revision: context.scenario.revision,
    profileId: context.profile.id,
  };
}

function planOracle(context) {
  const graph = graphOracle(context);
  const eligibleRepairs = context.candidates
    .filter(({ cost }) => cost.status !== 'unknown')
    .map(({ repairId, cost, severity }) => ({
      repairId, costCents: cost.cents, severityScore: severity.score,
    }))
    .sort((a, b) => b.severityScore - a.severityScore ||
      a.costCents - b.costCents || compareIds(a.repairId, b.repairId));
  const excludedUnknownCostRepairIds = context.candidates
    .filter(({ cost }) => cost.status === 'unknown')
    .map(({ repairId }) => repairId).sort(compareIds);
  const costs = new Map(eligibleRepairs.map(({ repairId, costCents }) => [repairId, costCents]));
  assert(costs.size <= 12);
  const evaluate = (ids) => {
    const outcomes = context.destinationIds.map((destinationId) => ({
      destinationId, route: graph.route(context.originNodeId, destinationId, ids),
    }));
    return { outcomes, reachableCount: outcomes.filter(({ route }) => route.status === 'reachable').length };
  };
  const baseline = evaluate([]);
  const baselineReachable = new Set(baseline.outcomes
    .filter(({ route }) => route.status === 'reachable').map(({ destinationId }) => destinationId));

  function projection(ids) {
    const coverage = evaluate(ids);
    return {
      ...coverage,
      restoredDestinationIds: coverage.outcomes
        .filter(({ destinationId, route }) => route.status === 'reachable' && !baselineReachable.has(destinationId))
        .map(({ destinationId }) => destinationId),
    };
  }
  // BigInt keeps breakpoint and aggregate arithmetic exact before conversion.
  const totalCost = (ids) => ids.reduce((sum, id) => sum + BigInt(costs.get(id)), 0n);
  const all = [...subsets([...costs.keys()].sort(compareIds))].map((ids) => ({
    ids, cost: totalCost(ids), gain: projection(ids).restoredDestinationIds.length,
  }));
  assert.equal(all.length, 2 ** costs.size);
  const breakpointBudgets = new Set([0, 199, 200, 399, 400, 599, 600, 799, 800, 900, Number.MAX_SAFE_INTEGER]);
  for (const { cost } of all) {
    for (const budget of [cost - 1n, cost, cost + 1n]) {
      if (budget >= 0 && budget <= BigInt(Number.MAX_SAFE_INTEGER)) breakpointBudgets.add(Number(budget));
    }
  }
  function output(ids) {
    const result = projection(ids);
    return {
      ...result,
      selectedRepairIds: ids,
      spendCents: Number(totalCost(ids)),
      restoredCount: result.restoredDestinationIds.length,
      withoutRepair: ids.map((repairId) => ({
        repairId, ...projection(ids.filter((id) => id !== repairId)),
      })),
    };
  }

  function comparison(input) {
    const budget = BigInt(input.budgetCents);
    const feasible = all.filter(({ cost }) => cost <= budget);
    const ranked = [...feasible].sort((a, b) => b.gain - a.gain ||
      (a.cost === b.cost ? 0 : a.cost < b.cost ? -1 : 1) ||
      a.ids.length - b.ids.length || compareLists(a.ids, b.ids));
    const chosen = [];
    for (const { repairId } of eligibleRepairs) {
      if (totalCost([...chosen, repairId]) <= budget) chosen.push(repairId);
    }
    const conditionFirst = output(chosen);
    const exact = output(ranked[0].ids);
    const union = [...new Set([...chosen, ...ranked[0].ids])].sort(compareIds);
    return {
      ...input, baseline, eligibleRepairs, excludedUnknownCostRepairIds, conditionFirst, exact,
      singleRepairs: union.map((repairId) => ({ repairId, ...projection([repairId]) })),
      search: { enumeratedSubsetCount: all.length, feasibleSubsetCount: feasible.length },
    };
  }

  return { comparison, budgets: [...breakpointBudgets].sort((a, b) => a - b) };
}

async function verifyPlans() {
  const group = 'core';
  const version = 'curb-r2';
  const contextPath = '/api/curb/plan-scenario';
  const planPath = '/api/curb/plan';
  const get = (query = '', expectedStatus = 200, code) =>
    request({ path: contextPath + query, expectedStatus, code, version, group });
  const post = (input, expectedStatus = 200, code) =>
    request({ path: planPath, expectedStatus, code, version, group, input });
  const first = await get();
  const context = first.value.data;
  assert.equal(context.scenario.id, 'synthetic-campus-repair-plans');
  assert.equal(context.scenario.dataKind, 'synthetic');
  assert.equal(context.originNodeId, 'arrival');
  assert.equal(context.defaultBudgetCents, 400);
  assert.deepEqual(context.destinationIds, ['library', 'student-center', 'hall', 'cafe', 'studio', 'archive']);
  const selector = '?' + new URLSearchParams({ scenarioId: context.scenario.id });
  assert.equal((await get(selector)).text, first.text);
  const oracle = planOracle(context);
  const input = {
    ...requestIdentity(context, version), originNodeId: context.originNodeId, budgetCents: 400,
  };
  const comparisons = [];
  const baselineStatuses = Object.fromEntries(oracle.comparison(input).baseline.outcomes
    .map(({ destinationId, route }) => [destinationId, route.status]));
  assert.deepEqual(baselineStatuses, {
    library: 'blocked', 'student-center': 'blocked', hall: 'blocked', cafe: 'reachable',
    studio: 'unknown', archive: 'disconnected',
  });
  for (const budgetCents of oracle.budgets) {
    const selection = { ...input, budgetCents };
    const expected = oracle.comparison(selection);
    const received = await post(selection);
    assert.deepEqual(received.value.data, expected, 'Independent plan comparison at budget ' + budgetCents);
    comparisons.push({
      budgetCents, elapsedMs: received.elapsedMs,
      conditionFirst: {
        ids: expected.conditionFirst.selectedRepairIds,
        spend: expected.conditionFirst.spendCents,
        restored: expected.conditionFirst.restoredDestinationIds,
      },
      exact: {
        ids: expected.exact.selectedRepairIds, spend: expected.exact.spendCents,
        restored: expected.exact.restoredDestinationIds,
      },
      search: expected.search,
    });
  }
  const golden = oracle.comparison(input);
  assert.deepEqual(golden.conditionFirst.selectedRepairIds, ['repair-c']);
  assert.deepEqual(golden.conditionFirst.restoredDestinationIds, ['hall']);
  assert.deepEqual(golden.exact.selectedRepairIds, ['repair-a', 'repair-b']);
  assert.deepEqual(golden.exact.restoredDestinationIds, ['library', 'student-center']);
  assert.equal(golden.conditionFirst.spendCents, 400);
  assert.equal(golden.exact.spendCents, 400);
  assert.deepEqual(golden.excludedUnknownCostRepairIds, ['repair-studio']);
  assert.deepEqual(golden.search, { enumeratedSubsetCount: 8, feasibleSubsetCount: 5 });
  for (const effect of [...golden.exact.withoutRepair, ...golden.singleRepairs.filter(({ repairId }) => repairId !== 'repair-c')]) {
    assert.deepEqual(effect.restoredDestinationIds, []);
  }

  const initial = await post(input);
  const warmHttpMs = [];
  for (let repeat = 0; repeat < 12; repeat++) {
    const reply = await post(input);
    assert.equal(reply.text, initial.text, 'Golden repeat must be byte-identical.');
    warmHttpMs.push(reply.elapsedMs);
  }
  const errorCases = [
    [{ budgetCents: -1 }, 400, 'INVALID_REQUEST'],
    [{ budgetCents: 0.5 }, 400, 'INVALID_REQUEST'],
    [{ budgetCents: Number.MAX_SAFE_INTEGER + 1 }, 400, 'INVALID_REQUEST'],
    [{ budgetCents: '400' }, 400, 'INVALID_REQUEST'],
    [{ budgetCents: undefined }, 400, 'INVALID_REQUEST'],
    [{ candidates: [] }, 400, 'INVALID_REQUEST'],
    [{ costs: [0] }, 400, 'INVALID_REQUEST'],
    [{ originNodeId: 'not-the-fixed-origin' }, 400, 'INVALID_REQUEST'],
    [{ profileId: 'unknown-profile' }, 400, 'INVALID_REQUEST'],
    [{ contractVersion: 'curb-r1' }, 400, 'INVALID_REQUEST'],
    [{ scenarioId: 'unknown-plan' }, 404, 'SCENARIO_NOT_FOUND'],
    [{ revision: input.revision + 1 }, 409, 'STALE_SCENARIO'],
  ];
  for (const [patch, status, code] of errorCases) await post({ ...input, ...patch }, status, code);
  await get('?scenarioId=unknown-plan', 404, 'SCENARIO_NOT_FOUND');
  await get('?scenarioId=a&scenarioId=b', 400, 'INVALID_REQUEST');
  await get('?scenarioId=', 400, 'INVALID_REQUEST');
  await get('?budgetCents=400', 400, 'INVALID_REQUEST');
  await request({ path: planPath, raw: '{', expectedStatus: 400, code: 'INVALID_REQUEST', version, group });
  assert.equal((await get()).text, first.text, 'Evaluation must not mutate the context.');
  return {
    scenarioId: context.scenario.id, destinationOrder: context.destinationIds, comparisons,
    errorCaseCount: errorCases.length + 5, deterministicRepeats: warmHttpMs.length,
    warmHttpMs, golden: initial.value.data,
  };
}

async function verifyR1() {
  const group = 'r1';
  const version = 'curb-r1';
  const ctxPath = '/api/curb/trip-scenario';
  const first = await request({ path: ctxPath, version, group });
  const context = first.value.data;
  assert.equal(context.scenario.id, 'synthetic-campus-links');
  assert.equal(context.scenario.dataKind, 'synthetic');
  const graph = graphOracle(context);
  const rows = [];
  for (const originNodeId of graph.originIds) {
    for (const destinationId of graph.destinationIds) {
      for (const repairId of [null, ...context.repairs.map(({ id }) => id)]) {
        const input = { ...requestIdentity(context, version), originNodeId, destinationId, repairId };
        const reply = await request({ path: '/api/curb/trip', group, version, input });
        const expected = {
          ...input,
          before: graph.route(originNodeId, destinationId, []),
          after: graph.route(originNodeId, destinationId, repairId === null ? [] : [repairId]),
        };
        assert.deepEqual(reply.value.data, expected, 'R1 comparison ' + JSON.stringify(input));
        rows.push({ originNodeId, destinationId, repairId, before: expected.before.status, after: expected.after.status });
      }
    }
  }
  const input = { ...requestIdentity(context, version), ...context.defaults, repairId: null };
  const invalid = [
    [{ scenarioId: 'unknown-trip' }, 404, 'SCENARIO_NOT_FOUND'],
    [{ revision: input.revision + 1 }, 409, 'STALE_SCENARIO'],
    [{ originNodeId: 'unknown-node' }, 400, 'INVALID_REQUEST'],
    [{ destinationId: 'unknown-destination' }, 400, 'INVALID_REQUEST'],
    [{ repairId: 'unknown-repair' }, 400, 'INVALID_REQUEST'],
    [{ profileId: 'unknown-profile' }, 400, 'INVALID_REQUEST'],
  ];
  for (const [patch, expectedStatus, code] of invalid) {
    await request({ path: '/api/curb/trip', group, version, input: { ...input, ...patch }, expectedStatus, code });
  }
  assert.equal((await request({ path: ctxPath, version, group })).text, first.text);
  return { count: rows.length, errorCaseCount: invalid.length, rows };
}

async function verifyFoundation() {
  const path = '/api/curb/scenario';
  const group = 'foundation';
  const baseline = await request({ path, group });
  const sample = await request({ path: path + '?dataset=sample', group });
  assert.equal(sample.text, baseline.text);
  assert.equal(sample.value.data.scenario.id, 'synthetic-campus-quad');
  assert.equal(sample.value.data.scenario.dataKind, 'synthetic');
  assert.deepEqual(sample.value.data.counts, { nodes: 9, edges: 12, destinations: 3, barriers: 4, evidence: 5 });
  const empty = await request({ path: path + '?dataset=empty', group });
  assert.equal(empty.value.data.scenario.id, 'synthetic-empty-campus');
  assert.deepEqual(empty.value.data.counts, { nodes: 0, edges: 0, destinations: 0, barriers: 0, evidence: 0 });
  await request({ path: path + '?dataset=invalid-reference', group, expectedStatus: 404, code: 'DATASET_NOT_FOUND' });
  assert.equal((await request({ path, group })).text, baseline.text);
  return { sample: sample.value.data.counts, empty: empty.value.data.counts, unsupportedStatus: 404, unchanged: true };
}

function stats(samples) {
  const sorted = [...samples].sort((a, b) => a - b);
  return {
    count: sorted.length, medianMs: sorted[Math.floor(sorted.length / 2)],
    p95Ms: sorted[Math.ceil(sorted.length * 0.95) - 1], maxMs: sorted.at(-1),
  };
}

const plans = await verifyPlans();
const r1 = await verifyR1();
const foundation = await verifyFoundation();
const evidence = {
  result: 'PASS', sourceSha, nodeVersion: process.version, base: base.origin,
  startedAt, completedAt: new Date().toISOString(), plans, r1, foundation,
  httpTimingWarmGolden: stats(plans.warmHttpMs),
  httpRequestsByGroup: Object.fromEntries(Object.entries(timings).map(([group, samples]) => [group, stats(samples)])),
};
await writeFile(join(import.meta.dirname, 'core-http-evidence.json'), JSON.stringify(evidence, null, 2) + '\n');
console.log(JSON.stringify({
  result: evidence.result, sourceSha, base: base.origin, completedAt: evidence.completedAt,
  planBudgets: plans.comparisons.map(({ budgetCents }) => budgetCents),
  planTypedErrors: plans.errorCaseCount, deterministicRepeats: plans.deterministicRepeats,
  r1Comparisons: r1.count, r1TypedErrors: r1.errorCaseCount, foundation,
  httpTimingWarmGolden: evidence.httpTimingWarmGolden, httpRequestsByGroup: evidence.httpRequestsByGroup,
}, null, 2));
