import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
import { readFile, writeFile, mkdir } from 'node:fs/promises';
import { join } from 'node:path';
const { chromium } = createRequire(import.meta.url)('C:/Users/vzhu0/.codex/worktrees/curb-f0-bootstrap/Curb/.curb-local/hackathon-kit/node_modules/playwright');
const origin = process.argv[2];
assert.match(origin, /^http:\/\/127\.0\.0\.1:\d+$/);
const url = origin + '/survey-replay/';
const output = import.meta.dirname;
const shots = join(output, 'screenshots');
await mkdir(shots, { recursive: true });
const original = JSON.parse(await readFile('public/survey-replay/survey.json', 'utf8'));
const result = { url, sha: 'ebc35b07590ad07ca990299da1d3b077190987d6', checks: [], findings: [] };
const entries = result.checks;
const note = (name, details = {}) => entries.push({ name, ...details });
const finding = (name, details = {}) => result.findings.push({ name, ...details });
const browser = await chromium.launch({ executablePath: 'C:/Program Files/Google/Chrome/Application/chrome.exe', headless: true });
result.chromeVersion = browser.version();
async function screenshot(page, name, fullPage = true) {
  await page.screenshot({ path: join(shots, name + '.png'), animations: 'disabled', fullPage });
}
const wait = (page, selector) => page.locator(selector).waitFor();
const ready = (page) => page.waitForFunction(() => {
  const v = document.querySelector('video');
  return v.readyState >= 2 && Number.isFinite(v.duration) && !document.querySelector('#play').disabled;
});
const metric = async (page) => await page.locator('.metric strong').allTextContents();
const scoped = async (name, fn, viewport = { width: 1365, height: 1050 }) => {
  const ctx = await browser.newContext({ viewport });
  const page = await ctx.newPage();
  page.setDefaultTimeout(8000);
  try { await fn(ctx, page); }
  catch (error) {
    result.checks.push({ name, harnessError: error.message });
    await screenshot(page, 'error-' + name).catch(() => {});
    process.exitCode = 1;
  } finally { await ctx.close(); }
};
async function showData(page, replacement) {
  await page.route('**/survey-replay/survey.json', (route) => route.fulfill(replacement));
  await page.goto(url);
}
try {
  await scoped('normal', async (ctx, page) => {
    const errors = [], external = [], videoReplies = [];
    page.on('pageerror', (e) => errors.push(e.message));
    page.on('request', (req) => { if (new URL(req.url()).origin !== origin) external.push(req.url()); });
    page.on('response', (reply) => {
      if (reply.url().endsWith('.mp4')) videoReplies.push({ status: reply.status(), range: reply.headers()['content-range'] });
    });
    await page.goto(url);
    await ready(page);
    const provenance = await page.locator('#media-label').textContent();
    assert.equal(provenance, 'Synthetic sample replay');
    assert.match(await page.locator('#footnote').textContent(), /synthetic fixed-scenario.*illustrative/i);
    const media = await page.locator('video').evaluate((v) => ({
      duration: v.duration, width: v.videoWidth, height: v.videoHeight,
    }));
    assert(media.duration > 20 && media.width > 0);
    assert.equal(await page.locator('.map-pin:visible').count(), 0);
    assert.deepEqual(await metric(page), ['0', '0 m']);
    assert.match(await page.locator('[data-destination="library"]').textContent(), /330 m/);
    for (const id of ['clinic', 'pharmacy']) assert.match(await page.locator('[data-destination="' + id + '"]').textContent(), /Blocked/);
    await page.locator('#play').click();
    await page.waitForFunction(() => document.querySelector('video').currentTime > 0.2);
    await page.locator('#play').click();
    await page.waitForFunction(() => document.querySelector('video').paused);
    await page.locator('[data-finding="surface-crack"]').click();
    await wait(page, '[data-annotation="surface-crack"]');
    const crack = await page.locator('video').evaluate((v) => v.currentTime);
    assert(crack >= 5.2 && crack < 5.5);
    assert.equal(await page.locator('[data-pin="surface-crack"]').isVisible(), true);
    assert.match(await page.locator('#finding-detail').textContent(), /Model annotation.*Reviewed/);
    await page.locator('[data-finding="raised-slab"]').click();
    await wait(page, '[data-annotation="raised-slab"]');
    const slab = await page.locator('video').evaluate((v) => v.currentTime);
    assert(slab >= 11.3 && slab < 11.6);
    assert.match(await page.locator('#finding-detail').textContent(), /Manual annotation.*Reviewed/);
    await page.locator('[data-pin="surface-crack"]').click();
    await page.locator('[data-selected-segment="maple-frontage"]').waitFor({ state: 'attached' });
    assert((await page.locator('video').evaluate((v) => v.currentTime)) < 6);
    await page.locator('[data-finding="raised-slab"]').click();
    await page.locator('[data-pin="raised-slab"]').click();
    await page.locator('[data-selected-segment="market-crossing"]').waitFor({ state: 'attached' });
    await page.locator('.photo-button').click();
    await wait(page, '#photo-dialog[open] #detail-photo');
    assert(await page.locator('#detail-photo').evaluate((img) => img.decode().then(() => img.naturalWidth > 0)));
    await page.keyboard.press('Escape');
    assert.equal(await page.locator('#photo-dialog').isVisible(), false);
    await page.locator('[data-repair="surface-crack"]').click();
    assert.deepEqual(await metric(page), ['0', '90 m']);
    assert.match(await page.locator('[data-destination="library"]').textContent(), /240 m/);
    await page.locator('[data-repair="raised-slab"]').click();
    assert.deepEqual(await metric(page), ['+2', '0 m']);
    assert.match(await page.locator('[data-destination="clinic"]').textContent(), /260 m/);
    assert.match(await page.locator('[data-destination="pharmacy"]').textContent(), /275 m/);
    await page.evaluate(() => window.scrollTo(0, 0));
    await screenshot(page, '01-desktop-annotation-repair');
    await page.locator('[data-repair="current"]').click();
    assert.deepEqual(await metric(page), ['0', '0 m']);
    await page.reload();
    await ready(page);
    assert.deepEqual(await metric(page), ['0', '0 m']);
    assert.equal(await page.locator('.map-pin:visible').count(), 0);
    assert.equal(await page.locator('video').evaluate((v) => v.currentTime), 0);
    assert.deepEqual(errors, []);
    assert.deepEqual(external, []);
    const mediaPath = origin + '/survey-replay/media/sidewalk-survey.mp4';
    const head = await ctx.request.head(mediaPath);
    assert.equal(head.status(), 200);
    assert.equal(head.headers()['content-type'], 'video/mp4');
    assert.equal(head.headers()['content-length'], '2516080');
    const ranges = [];
    for (const range of ['bytes=0-31', 'bytes=-32', 'bytes=32-', 'bytes=999999999-']) {
      const response = await ctx.request.get(mediaPath, {headers: { Range: range }});
      ranges.push({ range, status: response.status(), contentRange: response.headers()['content-range'],
        bytes: (await response.body()).length });
    }
    assert.deepEqual(ranges.slice(0, 3).map(({status}) => status), [206, 206, 206]);
    assert.deepEqual(ranges.slice(0, 3).map(({bytes}) => bytes), [32, 32, 2516080 - 32]);
    const outsideAsset = ranges[3];
    assert.equal(outsideAsset.status, 416);
    note('desktop normal flow and standalone media', { media, crackTime: crack, slabTime: slab, videoReplies, ranges, externalRequests: external.length });
  });

  await scoped('narrow-keyboard', async (_ctx, page) => {
    await page.goto(url);
    await ready(page);
    await page.locator('#step-review').focus();
    await page.keyboard.press('Tab');
    assert.equal(await page.locator('#step-compare').evaluate((el) => document.activeElement === el && el.matches(':focus-visible')), true);
    const outline = await page.locator('#step-compare').evaluate((item) => getComputedStyle(item).outlineWidth);
    assert.equal(outline, '3px');
    await page.keyboard.press('Enter');
    assert.equal(await page.locator('[data-repair="current"]').evaluate((el) => document.activeElement === el), true);
    await page.keyboard.press('Tab');
    await page.keyboard.press('Enter');
    assert.deepEqual(await metric(page), ['0', '90 m']);
    await page.locator('[data-finding="raised-slab"]').focus();
    await page.keyboard.press('Space');
    await wait(page, '[data-annotation="raised-slab"]');
    await page.locator('[data-pin="raised-slab"]').focus();
    await page.keyboard.press('Enter');
    await page.locator('[data-selected-segment="market-crossing"]').waitFor({ state: 'attached' });
    const bounds = await page.evaluate(() => ({ width: innerWidth, scroll: document.documentElement.scrollWidth }));
    assert.deepEqual(bounds, { width: 390, scroll: 390 });
    await page.evaluate(() => window.scrollTo(0, 0));
    await screenshot(page, '02-390px-keyboard');
    note('narrow keyboard', { ...bounds, outline, fullScreenReaderAudit: false });
  }, { width: 390, height: 844 });

  await scoped('authored-json-edit', async (_ctx, page) => {
    const edited = structuredClone(original);
    edited.findings[0].start = 7.4;
    edited.findings[0].end = 8.6;
    edited.findings[0].box = [0.2, 0.2, 0.5, 0.4];
    edited.findings[0].label = 'Visible <em>plain-text</em>';
    await showData(page, { status: 200, json: edited });
    await ready(page);
    await page.locator('[data-finding="surface-crack"]').click();
    await wait(page, '[data-annotation="surface-crack"]');
    const time = await page.locator('video').evaluate((v) => v.currentTime);
    assert(time >= 7.4 && time < 7.6);
    assert.equal(await page.locator('[data-annotation="surface-crack"]').textContent(), edited.findings[0].label);
    assert.equal(await page.locator('[data-annotation="surface-crack"] em').count(), 0);
    const box = await page.locator('[data-annotation="surface-crack"]').evaluate((node) => {
      const video = document.querySelector('video');
      const ratio = Math.min(video.clientWidth / video.videoWidth, video.clientHeight / video.videoHeight);
      const displayedWidth = video.videoWidth * ratio;
      return { actualWidth: node.getBoundingClientRect().width, expectedWidth: displayedWidth * 0.5 };
    });
    assert(Math.abs(box.actualWidth - box.expectedWidth) < 1);
    note('authored JSON edit', { time, box, escapedLabel: true });
  });

  for (const name of ['malformed-json', 'data-404', 'invalid-box', 'unknown-segment']) {
    await scoped(name, async (_ctx, page) => {
      const invalid = structuredClone(original);
      if (name === 'invalid-box') invalid.findings[0].box = [0.8, 0.8, 0.5, 0.4];
      if (name === 'unknown-segment') invalid.findings[0].segment = 'unlisted-segment';
      const reply = name === 'malformed-json' ? { status: 200, contentType: 'application/json', body: '{' }
        : name === 'data-404' ? { status: 404, body: '' } : { status: 200, json: invalid };
      await showData(page, reply);
      await page.getByText('Survey unavailable.', { exact: false }).waitFor();
      assert.equal(await page.locator('#workspace').isVisible(), false);
      if (name === 'malformed-json') await screenshot(page, '03-malformed-json');
      note('controlled ' + name, { message: await page.locator('#data-state').textContent() });
    });
  }
  await scoped('missing-video', async (_ctx, page) => {
    await page.route('**/*.mp4', route => route.fulfill({ status: 404, body: '' }));
    await page.goto(url);
    await page.getByText('The survey video could not load.', { exact: false }).waitFor();
    assert.equal(await page.locator('#play').isDisabled(), true);
    assert.equal(await page.locator('#seek').isDisabled(), true);
    assert.equal(await page.locator('[data-finding="raised-slab"]').isDisabled(), true);
    await page.locator('[data-repair="raised-slab"]').click();
    assert.deepEqual(await metric(page), ['+2', '0 m']);
    await screenshot(page, '04-missing-video');
    note('controlled local video 404', { timelineDisabled: true, graphStillAvailable: true });
  });
  const cases = {
    'numeric finding label': survey => { survey.findings[1].label = 12; },
    'review string true': survey => { survey.findings[1].assessment.reviewed = 'true'; },
    'review string false': survey => { survey.findings[1].assessment.reviewed = 'false'; },
    'review numeric flag': survey => { survey.findings[1].assessment.reviewed = 1; },
    'direction string': survey => { survey.segments[0].bidirectional = 'false'; },
    'baseline ID collision': survey => { survey.findings.push({ ...survey.findings[1], id: 'current', segment: 'bus-west' }); },
    'distance overflow': survey => { for (const segment of survey.segments) segment.meters = 1e308; },
    'remote video': survey => { survey.video.src = 'https://example.test/clip.mp4'; },
    'protocol-relative poster': survey => { survey.video.poster = '//example.test/poster.jpg'; },
    'traversal close-up': survey => { survey.findings[1].closeUp = 'media/../outside.jpg'; },
    'absolute video': survey => { survey.video.src = '/public/clip.mp4'; },
    'data poster': survey => { survey.video.poster = 'data:image/png,fixture'; },
    'javascript close-up': survey => { survey.findings[1].closeUp = 'javascript:alert(1)'; },
  };
  for (const [name, edit] of Object.entries(cases)) {
    await scoped(name, async (ctx, page) => {
      const requests = [];
      const errors = [];
      await ctx.route('**/*', route => {
        if (new URL(route.request().url()).origin === origin) return route.continue();
        return route.abort();
      });
      page.on('request', req => requests.push(req.url()));
      page.on('pageerror', error => errors.push(error.message));
      const invalid = structuredClone(original);
      edit(invalid);
      await showData(page, { status: 200, json: invalid });
      await page.getByText('Survey unavailable.', { exact: false }).waitFor();
      assert.equal(await page.locator('#workspace').isVisible(), false);
      assert.deepEqual(requests.filter(url => new URL(url).origin !== origin || url.includes('/media/')), []);
      assert.deepEqual(errors, []);
      if (name === 'review string true') await screenshot(page, '05-invalid-review');
      note(name, { message: await page.locator('#data-state').textContent(), mediaAttempts: 0 });
    });
  }
  await scoped('out-of-duration', async (_ctx, page) => {
    const edited = structuredClone(original);
    edited.findings[0].start = 300;
    edited.findings[0].end = 301;
    await showData(page, { status: 200, json: edited });
    await ready(page);
    const button = page.locator('[data-finding="surface-crack"]');
    const id = await button.getAttribute('aria-describedby');
    assert.equal(await button.isDisabled(), true);
    const message = page.locator('#' + id);
    assert.equal(await message.isVisible(), true);
    assert.match(await message.textContent(), /outside the loaded video/);
    await page.locator('[data-finding="raised-slab"]').focus();
    await page.keyboard.press('Enter');
    await wait(page, '[data-annotation="raised-slab"]');
    assert.deepEqual(await page.evaluate(() => [innerWidth, document.documentElement.scrollWidth]), [390, 390]);
    await screenshot(page, '06-out-of-duration');
    note('out-of-duration shown alongside usable sibling', { width: 390, describedBy: id, message: await message.textContent() });
  }, { width: 390, height: 844 });
  await scoped('replacement-geography', async (_ctx, page) => {
    const edited = structuredClone(original);
    edited.sample = false;
    edited.label = 'Replacement geography';
    edited.findings[1].assessment.reviewed = false;
    await showData(page, { status: 200, json: edited });
    await ready(page);
    assert.equal(await page.locator('#sample-profile').isVisible(), false);
    assert.equal(await page.locator('#map-legend').isVisible(), false);
    assert.equal(await page.locator('#street-map #routes line').count(), 0);
    assert.equal(await page.locator('[data-blocked="true"]').count(), 0);
    assert.equal(await page.locator('#repair-controls').isVisible(), false);
    assert.equal(await page.locator('[data-destination]').count(), 0);
    await page.locator('#step-compare').focus();
    await page.keyboard.press('Enter');
    assert.equal(await page.locator('#map-results').evaluate(el => document.activeElement === el), true);
    assert.match(await page.locator('#map-results').textContent(), /Comparison unavailable/);
    await page.locator('[data-finding="raised-slab"]').click();
    await wait(page, '[data-annotation="raised-slab"]');
    await wait(page, '[data-pin="raised-slab"]');
    assert.match(await page.locator('#finding-detail').textContent(), /Review pending · Passability unknown/);
    await screenshot(page, '07-replacement-geography');
    note('replacement geography supports evidence review only', { text: await page.locator('#map-results').textContent() });
  });
} finally {
  await browser.close();
  result.finishedAt = new Date().toISOString();
  await writeFile(join(output, 'browser-evidence.json'), JSON.stringify(result, null, 2) + '\n');
  console.log(JSON.stringify(result, null, 2));
}
